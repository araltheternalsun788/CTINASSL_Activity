import React from 'react'
import '../styles/header.css'

function header() {
    return (
        <>
            <header>
                <h1>My Website</h1>
                <p>With a <b>flexible</b> layout.</p>
            </header>

            <div class="navbar">
                <a href="#">Link</a>
                <a href="#">Link</a>
                <a href="#">Link</a>
                <a href="#">Link</a>
            </div>
        </>
    )
}

export default header